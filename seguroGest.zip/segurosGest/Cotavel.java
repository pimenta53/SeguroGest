
/**
 * Write a description of interface Bolsa here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public interface Cotavel
{
     double getValor();
     void setValorInicio(double valor);
     void setValorBolsa(double valor);

}
